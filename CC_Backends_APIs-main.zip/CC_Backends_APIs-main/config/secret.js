module.exports = {
  secret: 'akusayangkamuloh',
};
